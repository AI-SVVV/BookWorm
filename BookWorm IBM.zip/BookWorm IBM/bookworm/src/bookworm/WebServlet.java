package bookworm;

public @interface WebServlet {

}
