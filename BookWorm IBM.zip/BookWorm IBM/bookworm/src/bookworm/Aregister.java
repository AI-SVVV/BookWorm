package bookworm;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Aregister
 */
@WebServlet("/AdoReg")
public class Aregister extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fname=request.getParameter("user__first_name");
		String lname=request.getParameter("user__last_name");
		String email=request.getParameter("user__email");
		String pwd=request.getParameter("user__password");
	
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>Register Servlet</title></head>");
		out.println("<body>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver Loaded");
		    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookworm","root","root");
			System.out.println("Connected to Database");
			PreparedStatement pst=con.prepareStatement("insert into register(fname,lname,email,pwd) values(?,?,?,?)");
			pst.setString(1,fname);
			pst.setString(2,lname);
			pst.setString(3,email);
			pst.setString(4,pwd);
		
			int r=pst.executeUpdate();
			if(r!=0) {
				out.println("<h1>Registered Successfully</h1>");
				out.println("<h2>With UserName: "+fname+"</h2>");
				out.println("<p><button><a href=\"index.html\">home</a></button></p>");
				out.println("<p><button><a href=\"Alogin.html\">Login</a></button></p>");
			}else {
				out.println("<h1>Error In Registration</h1>");
				out.println("<p><a href=\"register.html\">Register</a></p>");
			}
			pst.close();
			con.close();
		}catch(Exception e) {
			out.println("Error "+e);
		}
		out.println("</body>");
		out.println("</html>");
		out.flush();
		out.close();
	}

}
