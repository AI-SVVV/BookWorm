package bookworm;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ShowAll
 */
@WebServlet("/ShowAll")
public class ShowAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><title>Show all Servlet</title></head> ");
		out.println("<body>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookworm","root","root");
			java.sql.Statement pst = con.createStatement();
			ResultSet rs = pst.executeQuery("select * from register");
			if (rs.next()){
				out.println("<table border = \"1\">");
			do {
				String fnm = rs.getString("fname");
				String lnm = rs.getString("lname");
				String email = rs.getString("email");
				out.println("<tr> <td>"+ fnm  +"</td><td>"+ lnm +"</td><td>"+ email +"</td></tr>") ;
			}
			while(rs.next());
				out.println("</table>");
			}
			else {
				out.println("<h2> Sorry</h2>");
			     }
			pst.close();
			con.close();
		
	            }
		catch (Exception e){
			out.println("Error " +e);
		}
		    out.println("</body>");
			out.println("</html>");
			out.flush();
			out.close();
	}

}
