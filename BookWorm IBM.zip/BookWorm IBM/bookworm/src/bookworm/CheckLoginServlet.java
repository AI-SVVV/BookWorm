package bookworm;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CheckLoginServlet
 */
@WebServlet("/ACheckLogin")
public class CheckLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String uid = request.getParameter("user__first_name");
		String pwd = request.getParameter("user__password");
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><title> Login </title></head> ");
		out.println("<body>");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookworm","root","root");
			PreparedStatement pst = con.prepareStatement("select fname,pwd from register where fname = ? and pwd = ?");
			pst.setString(1, uid);
			pst.setString(2, pwd);
			ResultSet rs = pst.executeQuery();
			if (rs.next()){
				String name = rs.getString(1);
				out.println("<h2>Welcome "+name+"</h2>");
				out.println("<br><br>");
			} else {
				out.println("<h2> Sorry ! Failed</h2>");
				out.println("<a href = \"login.html\"> Try again </a>");
			}
			pst.close();
			con.close();
		
	}
		catch (Exception e){
			out.println("</body>");
			out.println("</html>");
			out.flush();
			out.close();
	}

	}
}
